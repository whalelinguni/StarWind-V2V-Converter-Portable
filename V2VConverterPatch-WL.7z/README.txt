        ____            ___                          _                ___      _       _        ┈╭━━━━━━━━━━━╮┈
 /\   /\___ \/\   /\   / __\___  _ ____   _____ _ __| |_ ___ _ __    / _ \__ _| |_ ___| |__     ┈┃╭━━━╮┊╭━━━╮┃┈
 \ \ / / __) \ \ / /  / /  / _ \| '_ \ \ / / _ \ '__| __/ _ \ '__|  / /_)/ _` | __/ __| '_ \    ╭┫┃▇┈┃┊┃┈▇ ┃┣╮
  \ V / / __/ \ V /  / /__| (_) | | | \ V /  __/ |  | ||  __/ |    / ___/ (_| | || (__| | | |   ┃┃╰━━━╯┊╰━━━╯┃┃
   \_/ |_____| \_/   \____/\___/|_| |_|\_/ \___|_|   \__\___|_|    \/    \__,_|\__\___|_| |_|   ╰┫╭━╮╰━━━╯╭━╮┣╯
                                                                                                ┈┃┃┣┳┳┳┳┳┳┳┫┃┃┈
                                                                                                ┈┃┃╰┻┻┻┻┻┻┻╯┃┃┈
[--------- README ---------]								                        ┈╰━━━━━━━━━━━╯┈

Patch disables the popup/webpage link that opens when closing V2V Converter.

------------------------------
What was modified:
------------------------------
Original instruction:
[7FF717C95700]     | 00007FF717C95700:L"https://www.starwindsoftware.com/download-free-tools?intype=%d&inlocation=%d&outtype=%d&outlocation=%d&page=%d&res=%d&insize=%I64u&version=%s&id=%08x"

Hex:
[Original]
48 8D 15 08 A8 11 00  

[Modified]
90 90 90 90 90 90 90

Just changed to NOPs to skip.

------------------------------
How to patch
------------------------------
Open 'DeltaPatcher.exe'
Choose 'V2V_Converter.exe' for input exe
Choose 'V2VConvPopupPatch.xdelta' for patch
Apply Patch.

Note: DeltaPatcher I know has issues with symbols in file paths and names. If you get an error, try patch again with a cleaner path.


Enjoy!

 _       _  _             _              _                                          
( )  _  ( )( )           (_ )           ( )     _                       _         _ 
| | ( ) | || |__     _ _  | |    __     | |    (_)  ___     __   _   _ (_)  ___  (_)
| | | | | ||  _ `\ /'_` ) | |  /'__`\   | |  _ | |/' _ `\ /'_ `\( ) ( )| |/' _ `\| |
| (_/ \_) || | | |( (_| | | | (  ___/   | |_( )| || ( ) |( (_) || (_) || || ( ) || |
`\___x___/'(_) (_)`\__,_)(___)`\____)   (____/'(_)(_) (_)`\__  |`\___/'(_)(_) (_)(_)
                                                         ( )_) |                    
                                                          \___/'                    